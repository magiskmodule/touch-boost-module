# MTweaks V2.0
## Description
This Module Will Boost Multi-Touch Response in Android Games. Works With Both Mediatek And Snapdragon Devices. If You Like My Work Than Please Do Subscribe My YouTube Channel- Techno Treatment❤️. Note:- Tested On: Redmi Note 8 Pro(Mediatek) And PoCo F1(Snapdragon).

## Supported vendors
- MediaTek
- Snapdragon

## Supported Architectures
- Arm & Arm64
- x86 & x86_64

## Requirements
- Magisk v22.0 or higher

## Links
- <a href="https://t.me/TechnoTreatment">Official Telegram Group</a>
